<?php

/**
 * ProInvest Installer Library
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is available through the world-wide-web at this URL:
 * https://choosealicense.com/licenses/gpl-3.0/
 *
 * @category        Installer
 * @package         codeigniter/libraries
 * @version         1.0
 * @author          axis96
 * @copyright       Copyright (c) 2020 Axis96
 * @license         https://choosealicense.com/licenses/gpl-3.0/
 *
 *
 */

class Core_validation {
    function validate(){
        
    }
}